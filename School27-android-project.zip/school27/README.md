# Школа №27 — Android-приложение

Визуальная новелла в виде нативного Android-приложения (Kotlin + WebView). Работает полностью офлайн, запрос INTERNET не нужен.

- Название: «Школа №27», пакет `ru.school27.novel`, Android 8.0+ (minSdk 26)
- Игра: `app/src/main/assets/www/` (`index.html`, `js/app.js`, `js/story.js`, картинки, шрифты)
- Возможности: главный экран, «Продолжить» с автосохранением, выбор вариантов, журнал реплик, шаг назад, авточтение, скорость и размер текста, полноэкранный режим, кнопка «Назад» (закрыть окно → главный экран → выход по двойному нажатию)

## Как получить APK

**Вариант 1 — Android Studio.** File → Open → папка проекта, дождаться синхронизации, Build → Build APK(s). Файл: `app/build/outputs/apk/debug/app-debug.apk`.

**Вариант 2 — GitHub Actions (без установки чего-либо).** Загрузите проект в репозиторий GitHub. Вкладка Actions → «Build APK» → Run workflow. Готовый `app-debug.apk` будет в Artifacts.

**Вариант 3 — командная строка** (нужны JDK 17 и Android SDK): `./gradlew assembleDebug`.

Установка на телефон: скопируйте APK, откройте и разрешите установку из неизвестных источников.

## Для публикации в Google Play
Соберите подписанный `bundle`/`release` в Android Studio (Build → Generate Signed Bundle / APK) и смените `versionCode` в `app/build.gradle.kts` при каждом обновлении.

## Как менять историю
Сюжет — массив сцен в `app/src/main/assets/www/js/story.js`: `text`, `speaker`, `chars` (`igor`/`roma`/`nastya`), `bg` (`school`/`corridor`/`classroom`/`roma`/`igor`), `loc`, `choices` (`text`, `next` — номер сцены с нуля), `next`, `end`+`title`. Новые картинки кладите в `img/bg` и `img/chars`. Игру можно проверять просто открыв `index.html` в браузере.
