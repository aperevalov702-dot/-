plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.school27.novel"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.school27.novel"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Для публикации задайте свой signingConfig (см. README). Без него release-APK не подписан.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // JPG/WOFF2 уже сжаты — не пережимаем.
    androidResources { noCompress += listOf("jpg", "woff2", "js", "css", "html") }
}
