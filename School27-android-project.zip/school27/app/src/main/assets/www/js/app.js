(function () {
  "use strict";
  var STORY = window.STORY;
  var BG = { school: "school", corridor: "corridor", classroom: "classroom", roma: "roma", igor: "igor" };
  var LABEL = { igor: "Игорь", roma: "Рома", nastya: "Анастасия" };
  var SPEAKER_ID = { "Игорь": "igor", "Рома": "roma", "Анастасия": "nastya" };
  var KEY = "school27-save-v2";
  var SPEED_CPS = { slow: 26, med: 46, fast: 78 };
  var SIZE = { s: 0.9, m: 1, l: 1.2 };

  var $ = function (id) { return document.getElementById(id); };
  var st = { index: 0, path: [0], furthest: 0, speed: "med", size: "m" };
  var playing = false, shown = "", done = false, auto = false, timer = null, autoTimer = null;

  function load() {
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || "null");
      if (d && typeof d.index === "number" && Array.isArray(d.path) && STORY[d.index]) {
        return {
          index: d.index,
          path: d.path.filter(function (n) { return typeof n === "number" && STORY[n]; }),
          furthest: typeof d.furthest === "number" ? d.furthest : d.index,
          speed: SPEED_CPS[d.speed] ? d.speed : "med",
          size: SIZE[d.size] ? d.size : "m",
          started: !!d.started
        };
      }
    } catch (e) {}
    return null;
  }
  function save(started) {
    try {
      var o = { index: st.index, path: st.path.slice(-400), furthest: st.furthest, speed: st.speed, size: st.size, started: started !== false };
      localStorage.setItem(KEY, JSON.stringify(o));
    } catch (e) {}
  }
  function saveSettingsOnly() {
    var cur = load();
    try {
      localStorage.setItem(KEY, JSON.stringify(cur ? Object.assign({}, cur, { speed: st.speed, size: st.size }) :
        { index: 0, path: [0], furthest: 0, speed: st.speed, size: st.size, started: false }));
    } catch (e) {}
  }
  function clearSave() { try { localStorage.removeItem(KEY); } catch (e) {} }

  function dayOf(i) { return i >= 52 ? "День 2" : "День 1"; }

  function show(id) {
    ["title", "game"].forEach(function (s) { $(s).classList.toggle("on", s === id); });
  }
  function sheet(id, on) { $(id).classList.toggle("on", on); }
  function anySheet() { return ["logSheet", "menuSheet", "setSheet"].some(function (s) { return $(s).classList.contains("on"); }); }
  function closeSheets() { ["logSheet", "menuSheet", "setSheet"].forEach(function (s) { sheet(s, false); }); }

  function applySettings() {
    document.documentElement.style.setProperty("--ts", SIZE[st.size]);
    [["segSpeed", st.speed], ["segSpeed2", st.speed], ["segSize", st.size], ["segSize2", st.size]].forEach(function (p) {
      Array.prototype.forEach.call($(p[0]).children, function (b) { b.classList.toggle("on", b.dataset.v === p[1]); });
    });
  }

  function refreshTitle() {
    var s = load();
    var c = $("bContinue");
    if (s && s.started) {
      c.hidden = false;
      c.textContent = "Продолжить · " + dayOf(s.index);
      $("bNew").textContent = "Начать сначала";
      $("bNew").className = "btn ghost";
    } else {
      c.hidden = true;
      $("bNew").textContent = "Начать историю";
      $("bNew").className = "btn";
    }
  }

  function stopTyping() { if (timer) { clearInterval(timer); timer = null; } }
  function stopAuto() { if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; } }

  function render() {
    var sc = STORY[st.index];
    var chars = sc.chars || [];
    var sid = sc.speaker ? SPEAKER_ID[sc.speaker] : null;
    var bgKey = BG[sc.bg] || "school";
    var bg = $("bg"), url = "img/bg/" + bgKey + ".jpg";
    if (bg.getAttribute("src") !== url) { bg.setAttribute("src", url); bg.classList.remove("fade"); void bg.offsetWidth; bg.classList.add("fade"); }
    $("day").textContent = dayOf(st.index);
    $("loc").textContent = sc.loc || "Школа №27";
    $("bar").style.width = Math.round(st.furthest / Math.max(1, STORY.length - 1) * 100) + "%";

    var stage = $("stage");
    stage.innerHTML = "";
    chars.forEach(function (id) {
      var f = document.createElement("figure");
      f.className = (!sid || sid === id) ? "" : "dim";
      if (sid === id) f.classList.add("sp");
      var im = document.createElement("img");
      im.src = "img/chars/" + id + ".jpg"; im.alt = LABEL[id] || id; im.draggable = false;
      var cap = document.createElement("figcaption");
      cap.textContent = LABEL[id] || id;
      f.appendChild(im); f.appendChild(cap); stage.appendChild(f);
    });

    $("end").classList.toggle("on", !!sc.end);
    $("dock").style.display = sc.end ? "none" : "";
    if (sc.end) {
      $("endT").textContent = sc.title || "Конец";
      $("endX").textContent = sc.text;
      stopTyping(); stopAuto();
      return;
    }
    var spk = $("spk");
    spk.hidden = !sc.speaker;
    spk.textContent = sc.speaker || "";
    $("txt").className = sc.speaker ? "" : "narr";
    $("choices").innerHTML = "";
    $("dock").scrollTop = 0;
    typeText(sc.text);
  }

  function typeText(full) {
    stopTyping(); stopAuto();
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { finish(full); return; }
    var step = Math.max(1, Math.round(SPEED_CPS[st.speed] / 30)), i = 0;
    shown = ""; done = false;
    $("txt").textContent = "";
    updateMore();
    timer = setInterval(function () {
      i = Math.min(full.length, i + step);
      $("txt").textContent = full.slice(0, i);
      if (i >= full.length) { stopTyping(); finish(full); }
    }, 33);
  }

  function finish(full) {
    stopTyping();
    $("txt").textContent = full;
    done = true;
    var sc = STORY[st.index];
    var box = $("choices");
    box.innerHTML = "";
    if (sc.choices) {
      sc.choices.forEach(function (c) {
        var b = document.createElement("button");
        b.className = "choice"; b.textContent = c.text;
        b.addEventListener("click", function (e) { e.stopPropagation(); go(c.next); });
        box.appendChild(b);
      });
    }
    updateMore();
    $("dock").scrollTop = 0;
    if (auto && !sc.choices && !sc.end) autoTimer = setTimeout(advance, 1500);
  }

  function updateMore() {
    var sc = STORY[st.index];
    $("more").style.display = sc.choices ? "none" : "";
    $("moreT").textContent = done ? "нажмите, чтобы продолжить" : "нажмите, чтобы дочитать";
  }

  function go(n) {
    var safe = Math.max(0, Math.min(STORY.length - 1, n));
    st.path.push(safe); st.index = safe; st.furthest = Math.max(st.furthest, safe);
    save(); render();
  }
  function back() {
    if (st.path.length < 2) return;
    st.path.pop(); st.index = st.path[st.path.length - 1];
    save(); render();
  }
  function advance() {
    if (!playing || anySheet()) return;
    var sc = STORY[st.index];
    if (!done) { finish(sc.text); return; }
    if (sc.choices || sc.end) return;
    var n = sc.next !== undefined ? sc.next : st.index + 1;
    if (n >= STORY.length) return;
    go(n);
  }

  function begin(from) {
    if (from) { st = Object.assign({}, from); if (!st.path.length) st.path = [st.index]; }
    else { st.index = 0; st.path = [0]; st.furthest = 0; }
    playing = true; auto = false; setAutoUi();
    closeSheets(); show("game"); save(); render();
  }
  function toTitle() {
    playing = false; stopTyping(); stopAuto(); closeSheets(); show("title"); refreshTitle();
  }
  function restart() { clearSave(); begin(null); }

  function setAutoUi() {
    $("bAuto").classList.toggle("on", auto);
    $("autoIco").setAttribute("d", auto ? "M6 6h12v12H6z" : "M7 4l12 8-12 8z");
  }
  function openLog() {
    var ul = $("logl"); ul.innerHTML = "";
    st.path.slice(-120).forEach(function (n) {
      var s = STORY[n]; if (!s) return;
      var li = document.createElement("li");
      if (s.loc) { var a = document.createElement("small"); a.textContent = s.loc; li.appendChild(a); }
      if (s.speaker) { var b = document.createElement("b"); b.textContent = s.speaker; li.appendChild(b); }
      var p = document.createElement("p"); p.textContent = s.end ? (s.title || s.text) : s.text; li.appendChild(p);
      ul.appendChild(li);
    });
    sheet("logSheet", true);
    var sh = $("logSheet").firstElementChild; sh.scrollTop = sh.scrollHeight;
  }

  function bindSeg(id, key) {
    $(id).addEventListener("click", function (e) {
      var v = e.target.dataset && e.target.dataset.v; if (!v) return;
      st[key] = v; applySettings();
      if (playing) { save(); } else { saveSettingsOnly(); }
    });
  }

  function init() {
    var s = load();
    if (s) { st.speed = s.speed; st.size = s.size; }
    applySettings(); refreshTitle();
    $("bContinue").addEventListener("click", function () { var l = load(); if (l) begin(l); });
    $("bNew").addEventListener("click", function () { var l = load(); if (l && l.started) { clearSave(); } begin(null); });
    $("bSettings").addEventListener("click", function () { sheet("setSheet", true); });
    $("game").addEventListener("click", advance);
    ["bAuto", "bLog", "bMenu"].forEach(function (id) { $(id).addEventListener("click", function (e) { e.stopPropagation(); }); });
    $("bAuto").addEventListener("click", function () {
      auto = !auto; setAutoUi(); stopAuto();
      if (auto && done) { var sc = STORY[st.index]; if (!sc.choices && !sc.end) autoTimer = setTimeout(advance, 600); }
    });
    $("bLog").addEventListener("click", openLog);
    $("bMenu").addEventListener("click", function () { $("mBack").disabled = st.path.length < 2; sheet("menuSheet", true); });
    document.querySelectorAll(".sheet-bg").forEach(function (bg) {
      bg.addEventListener("click", function (e) { e.stopPropagation(); if (e.target === bg) bg.classList.remove("on"); });
    });
    document.querySelectorAll("[data-close]").forEach(function (b) {
      b.addEventListener("click", function (e) { e.stopPropagation(); closeSheets(); });
    });
    $("mBack").addEventListener("click", function () { back(); closeSheets(); });
    $("mHome").addEventListener("click", toTitle);
    $("mRestart").addEventListener("click", restart);
    $("bAgain").addEventListener("click", function (e) { e.stopPropagation(); restart(); });
    $("bHome").addEventListener("click", function (e) { e.stopPropagation(); toTitle(); });
    $("sReset").addEventListener("click", function () { clearSave(); refreshTitle(); closeSheets(); });
    bindSeg("segSpeed", "speed"); bindSeg("segSpeed2", "speed"); bindSeg("segSize", "size"); bindSeg("segSize2", "size");
    document.addEventListener("contextmenu", function (e) { e.preventDefault(); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { window.androidBack(); return; }
      if (!playing || anySheet()) return;
      if (e.key === " " || e.key === "Enter" || e.key === "ArrowRight") { e.preventDefault(); advance(); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); back(); }
    });
    document.addEventListener("visibilitychange", function () { if (document.hidden && playing) save(); });
  }

  /* Вызывается из Android при нажатии «Назад». true — событие обработано внутри. */
  window.androidBack = function () {
    if (anySheet()) { closeSheets(); return true; }
    if (playing) { toTitle(); return true; }
    return false;
  };
  window.androidPause = function () { stopTyping(); stopAuto(); if (playing) save(); };
  window.androidResume = function () { if (playing && !done) finish(STORY[st.index].text); };

  init();
})();
