package ru.school27.novel

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.IOException

/**
 * Весь интерфейс новеллы — в assets/www (HTML/CSS/JS). Activity только показывает его
 * в WebView, отдаёт файлы из assets по https://appassets.local/ (стабильный origin для
 * localStorage, без доступа к сети) и связывает системную кнопку «Назад» с игрой.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var lastBackAt = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        web = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#100E14"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isLongClickable = false
            setOnLongClickListener { true }
            isHapticFeedbackEnabled = false
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage для сохранений
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            textZoom = 100                      // системный масштаб шрифта не ломает вёрстку
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val uri = request.url
                if (uri.scheme != "https" || uri.host != HOST) return notFound()
                val path = uri.path.orEmpty().trimStart('/').ifEmpty { "index.html" }
                if (path.contains("..")) return notFound()
                return try {
                    val stream = assets.open("www/$path")
                    val ext = MimeTypeMap.getFileExtensionFromUrl(path)
                    val mime = when (ext) {
                        "js" -> "application/javascript"
                        "woff2" -> "font/woff2"
                        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                    }
                    WebResourceResponse(mime, "utf-8", stream)
                } catch (e: IOException) {
                    notFound()
                }
            }

            // Никуда за пределы игры не уходим.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true

            private fun notFound() =
                WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), "".byteInputStream())
        }

        setContentView(web)
        applyImmersive()

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://$HOST/index.html")
    }

    private fun applyImmersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Спрашиваем игру: закрыть окно / вернуться на главный экран. Если нечего закрывать — выход по двойному нажатию.
        web.evaluateJavascript("(function(){return window.androidBack?window.androidBack():false})()") { r ->
            if (r == "true") return@evaluateJavascript
            val now = System.currentTimeMillis()
            if (now - lastBackAt < 2000) {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            } else {
                lastBackAt = now
                Toast.makeText(this, "Нажмите «Назад» ещё раз, чтобы выйти", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        web.evaluateJavascript("window.androidPause&&window.androidPause()", null)
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.androidResume&&window.androidResume()", null)
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private companion object {
        const val HOST = "appassets.local"
    }
}
